<?php
/**
 * Widgets Functions
 *
 * @since 1.0.0
 */

if(!function_exists('logo_showcase_elementor_animate_class')) {
	function logo_showcase_elementor_animate_class($addon_animate,$effect,$delay) {
		if($addon_animate == 'on') : 
			$animate_class = ' animate-in" data-anim-type="'.$effect.'" data-anim-delay="'.$delay.'"'; 
		else :
			$animate_class = '"';
		endif;		
		return $animate_class;
	}
}

?>